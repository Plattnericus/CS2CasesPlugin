MCCases Fusion HD · 1.2.2
Current models, 128px skin textures and inspect geometry in assets/mccases/.
Custom server fonts, glyphs and pack icon are preserved byte-for-byte.
This exact combined pack is embedded in the matching plugin JAR.
Builds and /csadmin exportpack always apply the Fusion overlay.
Enable resource-pack.enabled and load this ZIP in Minecraft, or configure distribution.
Use /cases open <case> 9 for nine simultaneous 3x glass wheels.
The MCCases namespace is generated; put server artwork in its own namespace.
FUSION-MANIFEST.json records preserved assets and build provenance.
See LEGAL-NOTICE.txt for project and asset-use information.
