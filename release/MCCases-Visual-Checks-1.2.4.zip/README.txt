MCCases 1.2.4 visual checks
30 native Vanilla Minecraft 26.3 screenshots: 18 wheel views and 12 menu views.
Nine client transform dumps verify constant glass width for grid sizes 1..9.
The verification report, successful logs and result manifests are included.
Historical artwork/animation reports and release checksums: https://github.com/Plattnericus/CS2CasesPlugin
