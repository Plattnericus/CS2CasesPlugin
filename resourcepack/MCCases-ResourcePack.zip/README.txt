MCCases resource pack (optional)
-----------------------------------
Models and textures live in assets/mccases/.
Skin textures are rendered from the active MCCases catalog and bundled weapon maps.
In first person and during inspects the holder's own Minecraft skin arms hold the
weapon; the arms are drawn from each player's own skin by their own client.
Case artwork source and hashes are included in case-art/SOURCE.md.
assets/minecraft/shaders/ holds the Vanilla 26.3 entity and item programs with
MCCases additions: metal shading for marked faces, the skin arms and the split
between the first- and third-person inspect scenes. They require Minecraft 26.3.
Merge both the namespace and these shader programs into another pack.

Enable it in plugins/MCCases/config.yml -> resource-pack.enabled: true
only when every player has this pack loaded; otherwise the items show
the missing-model texture.
