MCCases resource pack (optional)
-----------------------------------
Everything lives in assets/mccases/ and no vanilla file is replaced.
To merge with another pack, copy the assets/mccases folder into that pack.

Enable it in plugins/MCCases/config.yml -> resource-pack.enabled: true
only when every player has this pack loaded; otherwise the items show
the missing-model texture.
